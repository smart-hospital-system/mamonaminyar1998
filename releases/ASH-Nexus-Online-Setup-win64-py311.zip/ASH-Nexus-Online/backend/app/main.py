"""ASH Nexus foundation. Run setup first; no built-in passwords or demo patient records."""
import os
import secrets
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.exc import IntegrityError
from .backups import SCHEMA_VERSION
from .database import open_database
from .models import Base, Setting
from .routers import auth, clinical, system
from .security import hash_password

ROOT = Path(__file__).resolve().parents[2]


def create_app(db_path=None, secure_cookie=None):
    path = Path(db_path or os.environ.get('ASH_DB_PATH', ROOT / '.data' / 'ash.sqlite3')).resolve()
    engine, sessions = open_database(path)

    @asynccontextmanager
    async def lifespan(app):
        # Setup and migrations are explicit; never silently rewrite a live schema.
        from sqlalchemy import inspect
        if not inspect(engine).has_table('settings'):
            raise RuntimeError('Database is not initialized. Run: python -m scripts.manage init')
        with sessions() as db:
            version = db.get(Setting, 'schema_version')
            if not version or version.value != SCHEMA_VERSION:
                raise RuntimeError('Unsupported schema. Back up and run a reviewed migration.')
        yield
        engine.dispose()

    app = FastAPI(title='ASH Nexus HMS — Foundation', version='0.1.0', lifespan=lifespan,
                  docs_url=None, redoc_url=None, openapi_url=None)
    app.state.engine, app.state.sessions = engine, sessions
    app.state.secure_cookie = secure_cookie if secure_cookie is not None else os.environ.get('ASH_SECURE_COOKIE', '0') == '1'
    app.state.dummy_hash = hash_password(secrets.token_urlsafe(32))

    @app.middleware('http')
    async def security_headers(request: Request, call_next):
        response = await call_next(request)
        response.headers['Cache-Control'] = 'no-store'
        response.headers['X-Content-Type-Options'] = 'nosniff'
        frame_ancestors = os.environ.get('ASH_FRAME_ANCESTORS', "'self'")
        if frame_ancestors == "'self'":
            response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        response.headers['Referrer-Policy'] = 'no-referrer'
        response.headers['Permissions-Policy'] = 'camera=(), microphone=(), geolocation=()'
        response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'" + f"; frame-ancestors {frame_ancestors}"
        return response

    @app.exception_handler(IntegrityError)
    async def integrity_error(request, error):
        # No SQL values or patient details are exposed in the HTTP response.
        return JSONResponse({'detail': 'تداخل اطلاعات: نام کاربری، بستر یا بستری فعال تکراری است.'}, status_code=409)

    @app.get('/healthz')
    def health():
        return {'status': 'ok', 'version': '0.1.0', 'mode': 'foundation-not-clinically-validated',
                **({'launch_id': os.environ['ASH_LAUNCH_ID']} if os.environ.get('ASH_LAUNCH_ID') else {})}

    for router in (auth.router, clinical.router, system.router):
        app.include_router(router)

    @app.get('/')
    def index():
        return FileResponse(ROOT / 'frontend' / 'index.html')

    app.mount('/assets', StaticFiles(directory=ROOT / 'frontend'), name='assets')
    return app


app = create_app()
