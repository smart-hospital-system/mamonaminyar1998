"""Small, explicitly incomplete vocabulary. NOT a diagnostic or dosing engine."""
import re
import unicodedata


def normalize(text):
    return re.sub(r'\s+', ' ', unicodedata.normalize('NFKC', text).lower().replace('ي', 'ی').replace('ك', 'ک')).strip()


SYMPTOMS = [
    ('تب', 'fever'), ('سرفه', 'cough'), ('سردرد', 'headache'), ('درد شکم', 'abdominal pain'),
    ('درد سینه', 'chest pain'), ('نفس‌تنگی', 'shortness of breath'), ('تهوع', 'nausea'),
    ('استفراغ', 'vomiting'), ('اسهال', 'diarrhea'), ('سرگیجه', 'dizziness'),
    ('خستگی', 'fatigue'), ('درد مفصل', 'joint pain'), ('حساسیت', 'allergy'),
    ('بیهوشی', 'unconsciousness'), ('خونریزی', 'bleeding'), ('کاهش اشتها', 'loss of appetite'),
]
SOURCES = [
    {'name': 'WHO — منابع رسمی مراقبت صحی', 'url': 'https://www.who.int/'},
    {'name': 'DailyMed — برچسب رسمی دواها', 'url': 'https://dailymed.nlm.nih.gov/dailymed/'},
    {'name': 'NICE BNF — مرجع تجویز', 'url': 'https://bnf.nice.org.uk/'},
]
DISCLAIMER = 'پوشش محدود و اعتبارسنجی بالینی‌نشده؛ نبود هشدار به معنی بی‌خطر بودن نیست. این ابزار تشخیص یا دوز تجویز نمی‌کند.'


def support(items, patient):
    names = [normalize(item['name']) for item in items]
    has = lambda words: any(any(word in name for word in words) for name in names)
    warnings = []
    if has(['warfarin', 'وارفارین']) and has(['aspirin', 'اسپرین', 'آسپرین']):
        warnings.append('وارفارین و اسپرین: احتمال افزایش خطر خونریزی؛ بازبینی داکتر لازم است.')
    if len(names) != len(set(names)):
        warnings.append('نام دوای تکراری وجود دارد؛ شکل، قدرت و ضرورت تکرار بررسی شود.')
    if patient.age < 18:
        warnings.append('مریض زیر ۱۸ سال است؛ این ابزار دوز اطفال را محاسبه نمی‌کند.')
    if patient.allergies.strip():
        warnings.append('حساسیت در دوسیه ثبت شده است؛ همهٔ دواها را با سابقهٔ حساسیت مقایسه کنید.')
    return {'warnings': warnings, 'disclaimer': DISCLAIMER, 'sources': SOURCES, 'coverage': 'limited-rules-v1',
            'auto_dosing': False, 'mandatory_injections': False}
