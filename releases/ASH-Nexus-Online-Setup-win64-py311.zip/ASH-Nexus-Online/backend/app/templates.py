"""Twenty print layouts; the same metadata drives the picker and A4 renderer."""
NAMES = [
    ('ایبک کلاسیک', 'classic', '#147d78', 'center', 'solid', 'striped'),
    ('جراحی امضادار', 'signature', '#853c57', 'split', 'double', 'plain'),
    ('مینیمال کلینیک', 'minimal', '#334155', 'left', 'none', 'rules'),
    ('هندسهٔ آبی', 'geometric', '#2454a5', 'band', 'solid', 'grid'),
    ('قاب زمرد', 'emerald', '#12705a', 'split', 'frame', 'striped'),
    ('خط عمودی', 'rail', '#725239', 'rail', 'none', 'rules'),
    ('مهر سلطنتی', 'royal', '#63448b', 'center', 'double', 'grid'),
    ('مدرن دو ستونه', 'columns', '#146984', 'split', 'solid', 'plain'),
    ('کارت‌های بالینی', 'cards', '#485aa0', 'left', 'round', 'striped'),
    ('نسخهٔ تایپوگرافیک', 'editorial', '#303a3a', 'band', 'none', 'rules'),
    ('طرح اطفال', 'pediatric', '#a15a1c', 'center', 'round', 'plain'),
    ('خطوط دقیق', 'precision', '#316465', 'rail', 'double', 'grid'),
    ('کتابچهٔ داکتر', 'notebook', '#466444', 'left', 'frame', 'rules'),
    ('ترکیب آجری', 'terracotta', '#a1523e', 'split', 'round', 'grid'),
    ('مدال شفاخانه', 'medallion', '#715f30', 'center', 'frame', 'plain'),
    ('نواری دیجیتال', 'digital', '#3058b0', 'band', 'double', 'striped'),
    ('مونوکروم حرفه‌ای', 'mono', '#141414', 'rail', 'solid', 'plain'),
    ('آرامش یاسی', 'lilac', '#775b84', 'left', 'round', 'grid'),
    ('افق ایبک', 'horizon', '#296a88', 'split', 'none', 'rules'),
    ('آرشیف استاندارد', 'archive', '#46505d', 'center', 'solid', 'grid'),
]
TEMPLATES = [dict(id=i, name=name, slug=slug, color=color, header=header, border=border, table=table,
                  footer=('columns', 'center', 'line', 'split')[i % 4], density=('normal', 'compact', 'airy')[i % 3])
             for i, (name, slug, color, header, border, table) in enumerate(NAMES, 1)]
