"""Application-owned SQLite connection; no imports from main or routers."""
from pathlib import Path
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker


def open_database(path: Path):
    path = path.resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    engine = create_engine(f'sqlite:///{path.as_posix()}', connect_args={'check_same_thread': False, 'timeout': 20})

    @event.listens_for(engine, 'connect')
    def configure(connection, _):
        connection.execute('PRAGMA foreign_keys=ON')
        connection.execute('PRAGMA busy_timeout=20000')
        connection.execute('PRAGMA journal_mode=WAL')

    return engine, sessionmaker(bind=engine, expire_on_commit=False)


def get_db(request):
    # Used via the typed dependency in security.py.
    with request.app.state.sessions() as db:
        yield db
