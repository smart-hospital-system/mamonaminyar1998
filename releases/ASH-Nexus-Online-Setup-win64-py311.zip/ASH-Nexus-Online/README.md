# ASH Nexus HMS — Aibak Hospital

پایهٔ واقعی سیستم مدیریت **شفاخانه ده بستر جراحی ایبک**، نسخهٔ ۰.۱.

A local-first, Dari/RTL hospital foundation with a FastAPI API, SQLite persistence,
role-scoped workflows, a dependency-free browser UI and twenty A4 print layouts.
**Not clinically validated or approved for production patient records.**

## Separate setup packages

The new setup release provides **separate online and offline ZIPs**, each started
by double-clicking `Setup.cmd`. A loopback-only browser wizard guides location,
hospital profile, administrator creation, activation and launch. **These are not
standalone compiled EXE installers: Windows x64 CPython 3.11 x64 must already exist.**
Online means dependency download, not cloud hosting.

- [راهنمای نصب‌کننده‌ها و فعال‌سازی](docs/INSTALLERS_FA.md)
- Requested distributable ZIPs and checksums are in `releases/`.
- Optional Ed25519 signed activation requires an issuer-owned public key; the
  ordinary bundles use local initialization, not a fake commercial serial.

## Start here

- [راهنمای کامل فارسی: نصب، استفاده، چاپ، بکاپ و محدودیت‌ها](docs/SETUP_FA.md)
- [ممیزی تاریخی کد ارسالی و خطاهای بازتولیدشده](docs/TECHNICAL_AUDIT_FA.md)

The previously described application was absent at the start of the audit. This
implementation was built here from scratch; it is not an export of that environment.
The historical audit remains as evidence, not as a description of today's file tree.

## Run locally

Python 3.11+ (the prepared offline bundle targets Windows x64 / CPython 3.11):

```bash
python -m venv .venv
# Windows: use .venv/Scripts/python.exe in place of .venv/bin/python
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m scripts.manage init
.venv/bin/python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000 --no-access-log
```

Open `http://127.0.0.1:8000`. Initialization prompts privately for a unique
administrator password. No default passwords or sample patient records are shipped. Windows scripts are in `scripts/`; offline installation uses the bundled
`wheelhouse` and `Install-Windows.ps1 -Offline`. Node is not needed to run the product.

## Implemented scope

- Hash-based password storage, revocable server sessions, CSRF and six roles.
- Persistent patient records, unique MRNs, explicit allergies/history and search.
- Doctor-owned draft/edit/confirm prescription workflow with optimistic revisions.
- Archived patient/hospital information on confirmation and shared print renderer.
- Twenty distinct layout configurations, print preview and browser print/PDF.
- Basic stock management with atomic non-negative withdrawals.
- Doctor-requested laboratory/radiology orders and department-restricted results.
- Ten-bed allocation, single active admission per patient and doctor discharge.
- Audit events, consistent database snapshots and validated restore to a new path.
- Small symptom vocabulary and explicitly incomplete rule-based safety reminders.

**Not implemented:** validated clinical AI/RAG, automatic diagnosis/dosing, comprehensive
drug interactions, surgery/anesthesia, billing, expiry/batch tracking, attachments,
FHIR, legal digital signatures, automatic backups, or a standalone Python installer.
No mandatory serum/injection or hidden drug-name correction is performed.

## Architecture

```text
backend/app/
  database.py       # independent connection/session factory, FK enforcement
  models.py         # single model module, correct Doctor/Prescription relationships
  security.py       # scrypt, sessions, CSRF, role dependencies, audit helper
  schemas.py        # bounded request validation
  routers/          # auth/users, clinical workflows, settings/backup/limited support
  templates.py      # twenty shared layout configurations
  knowledge.py      # explicitly incomplete vocabulary/rules, no treatment engine
  backups.py        # SQLite backup API and new-file-only restore
  main.py           # app factory, lifespan schema check, same-origin static UI
frontend/           # local HTML/CSS/JS; no external asset dependency
scripts/            # interactive setup, backup/restore and offline packaging
```

Runtime settings: `ASH_DB_PATH` (default `.data/ash.sqlite3`),
`ASH_SECURE_COOKIE=1` behind HTTPS, and optional `ASH_FRAME_ANCESTORS` for explicitly
trusted embedding origins. No `.env` loader is assumed. Do not expose a development
server directly to the internet or record query strings containing patient searches.
The bundled UI uses relative `/api` URLs; it never calls the user's localhost from a
hosted preview.

## Verification

```bash
.venv/bin/python -m pip install -r requirements-dev.txt
.venv/bin/python -m pytest tests/integration tests/audit tests/setup -q
npm ci
npm test
npm run check
```

Current verification: 28 application integration tests + 7 isolated historical audit
checks + 14 installer/signature tests (49 Python checks), and 13 simulated-API DOM
checks (8 application, 5 wizard). Persistence/restart, privileges, CSRF, session
revocation, stock/admission invariants, archived documents and snapshot restore are
covered. These are not a physical-printer test, clinical validation, Windows execution
or an independent security review. An additional real Chromium smoke workflow
covered login, patient creation, doctor draft/edit/confirm, mobile navigation and
PDF generation for all twenty layouts; the long synthetic document retained its
last item over seven pages. See [verification details](docs/VERIFICATION.md).
One upstream TestClient/AnyIO deprecation warning
is currently emitted.

A generated offline package intentionally excludes `.data`, backups, `.env`, passwords,
virtual environments and patient records. See the Persian guide for installation,
secure handling, restore drills and the release gate before any real clinical use.
