# Verification record — foundation 0.1

The project is a new implementation, not recovered code from the prior environment.
All test data are synthetic. No clinical validity or production readiness is implied.

## Automated suites

- `python -m pytest tests/integration tests/audit -q`: **33 passing**
  - 26 application integration checks.
  - 7 historical isolated defect reproductions / corrected examples.
- `npm test`: **8 passing**, using JSDOM and simulated API responses.
- `npm run check`: JavaScript syntax check passed.
- `python -m pip check`: no broken dependencies.
- `python -m compileall -q backend scripts`: passed.
- `git diff --check`: passed at the time of review.

The application integration tests cover roles/CSRF, password hashing, revocation,
failed-login limiting, record update/restart persistence, twenty layouts, draft
revision conflicts, archived confirmed documents, incomplete support disclosures,
atomic stock withdrawals, department-bound results, ten-bed invariants and backup
restore into a new database. One upstream TestClient/AnyIO deprecation warning remains.

## Real Chromium workflow

`tests/e2e/browser-smoke.cjs` was executed against the running sandbox TEST server:

1. Administrator login and creation of a clearly labelled synthetic patient.
2. Temporary doctor account creation through the authenticated API.
3. Doctor login, patient selection, empty draft (no mandatory medications).
4. Manual synthetic item, draft save, edit and physician confirmation.
5. Browser PDF generation of the stored document in all **20** layouts.
6. Template gallery with twenty cards.
7. Administrator login, deactivation of temporary test doctor.
8. Desktop (1440 × 1000) and mobile (390 × 844) rendering.
9. Mobile menu opening/closing and no horizontal document overflow.
10. No `pageerror` events in the tested workflow.

Browser tooling: Playwright Core 1.56.1, packaged Chromium 138.0.2. It is **optional
Linux verification tooling**, not a runtime dependency or part of the Windows bundle.
It was installed in ignored `.cache/browser-tools`. Bundled AL2023 NSS/NSPR libraries
were extracted locally because this sandbox lacks them. Browser security was not
disabled for the workflow (the packaged `--disable-web-security` and
`--allow-running-insecure-content` arguments are explicitly filtered out).

The browser test requires `ASH_E2E_USERNAME`, `ASH_E2E_PASSWORD` and optionally
`ASH_E2E_URL`. These must identify a TEST-only administrator. Credentials are not
stored in the test source. **Do not run it against real patient records**: it retains
synthetic patients/prescriptions and deactivates the temporary doctor account.

Example after installing the optional browser tooling and required OS libraries:

```bash
NODE_PATH="$PWD/.cache/browser-tools/node_modules" \
  ASH_E2E_USERNAME='test-admin' ASH_E2E_PASSWORD="$TEST_ADMIN_PASSWORD" \
  node tests/e2e/browser-smoke.cjs
```

`tests/e2e/check_pdfs.py` independently parses the resulting PDFs using optional
`pypdf` tooling. All twenty short synthetic documents were one A4 page (approximately
595.28 × 841.89 points) with their test text retained. The thirty-row long synthetic
print document spanned **seven pages**, with the final item present. Screenshots were
reviewed for the desktop login/dashboard, mobile dashboard and prescription preview.
Artifacts are in ignored `.cache/browser-output`, not in Git or the release archive.

These checks do **not** establish print fidelity on every browser, physical-printer
behavior, proper clinical content, or a legal electronic signature.

## Offline release checks

- Downloaded 16 wheels targeting CPython 3.11, Windows x64, including the explicit
  Windows Click dependency `colorama`.
- Dependency resolution succeeded with `--no-index`, target Windows x64 and the
  local wheelhouse. Actual installation on Windows was **not** performed here.
- ZIP integrity checked; source compilation checked after extraction.
- Archive excludes `.data`, `.env`, `.venv`, `.git`, Python caches and preview credentials.
- The interpreter installer, medical-reference corpus and browser-test toolchain are
  **not** included. Windows CPython 3.11 x64 must already be installed.

## Remaining release gates

Independent security review, Windows installation test, physical print testing,
clinical review of workflows, source/licensing and validation of any medical
knowledge additions, retention/encryption policies, recovery drills, and organization
approval are still required before real clinical use. A green test suite does not
replace those gates.


## Setup release 0.2 — current turn

- Python suite including `tests/setup`: **49 passing** (28 application, 7 historical,
  14 setup/signature/packaging checks).
- DOM suite: **13 passing** (8 application and 5 installer wizard checks).
- Signed activation tests cover signature tampering, wrong issuer, wrong product,
  optional installation binding, expiry, retry without repeating dependency install,
  role-protected renewal and continued access to existing records after expiry.
- Installer HTTP tests assert loopback binding, private bearer capability, Host/Origin
  checks, no token in the served page and no request logging.
- Commands are tested to distinguish online pip download from offline `--no-index`.
- A real **online development installation on Linux** completed dependency install,
  administrator/hospital provisioning, installed model checks and app lifespan startup
  in a fresh temporary target. The target was removed after the smoke test. This is
  not a Windows installer execution test.
- Updated Windows wheelhouse: **19 wheels**, with offline dependency resolution
  checked without an index. No Python interpreter installer is bundled.
- The wizard is launched with `Setup.cmd` in a ZIP, **not a compiled Setup.exe**.
  Windows shell/COM shortcut behavior and execution on a clean Windows machine are
  still unverified. The currently distributed bundles use local setup activation;
  a signed-license edition must be built using the owner's public key.

The browser E2E/PDF evidence in the preceding section belongs to the earlier
foundation workflow. This turn's wizard UI tests use JSDOM; they are not represented
as native Windows or real-browser wizard tests.
