// DOM-level checks with simulated API responses, not real-browser print tests.
const {test,afterEach}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const {JSDOM}=require('jsdom');
const html=fs.readFileSync('frontend/index.html','utf8');
const source=fs.readFileSync('frontend/app.js','utf8');
const fixtures={hospital:{name:'شفاخانهٔ آزمایشی',english_name:'TEST HOSPITAL',services:'test',phone:'test',address:'test address',email:'',website:'',template_id:1},
 templates:Array.from({length:20},(_,i)=>({id:i+1,name:`طرح ${i+1}`,slug:'classic',color:'#147d78',header:['center','split','rail','band'][i%4],border:'solid',table:'grid',footer:'columns',density:'normal'})),
 stats:{patients:1,prescriptions:1,medicines:0,low_stock:0,lab:0,radiology:0,occupied_beds:0}};
const person={id:1,mrn:'ASH-0000001',first_name:'مریض آزمایشی',last_name:'نمونه',father_name:'',age:30,sex:'female',weight_kg:60,allergies:'',phone:'',history:''};
let windows=[];
afterEach(()=>{for(const w of windows)w.close();windows=[];});
const settle=()=>new Promise(resolve=>setImmediate(resolve));
async function app(role='admin'){
 const dom=new JSDOM(html,{url:'http://localhost/',runScripts:'outside-only',pretendToBeVisual:true});
 const w=dom.window;windows.push(w);const requests=[];
 w.scrollTo=()=>{};w.confirm=()=>true;w.print=()=>{};
 w.fetch=async(url,options={})=>{
  requests.push({url,options});const path=url.split('?')[0];let data;
  if(path==='/api/auth/me')data={user:{id:1,name:'کارمند آزمایشی',role,username:'test'},csrf:'test-csrf'};
  else if(path==='/api/hospital')data=options.body?JSON.parse(options.body):fixtures.hospital;
  else if(path==='/api/templates')data=fixtures.templates;
  else if(path==='/api/dashboard')data=fixtures.stats;
  else if(path==='/api/patients')data=options.method==='POST'?person:[person];
  else if(path==='/api/prescriptions')data=[];
  else if(path==='/api/auth/logout')data={ok:true};
  else if(path==='/api/knowledge/symptoms')data={matches:[{label:'سردرد'}]};
  else data=[];
  return {ok:true,status:200,json:async()=>data,blob:async()=>new w.Blob(['test'])};
 };
 vm.runInContext(source+'\nwindow.testAPI={S,navigate,printSheet,rxModal,preview,resetLogin,readRx,esc};',dom.getInternalVMContext());
 for(let i=0;i<6;i++)await settle();
 return {w,api:w.testAPI,requests};
}
test('login page has no default credentials or session localStorage',async()=>{
 const {w,api}=await app();api.resetLogin();assert.ok(w.document.querySelector('#login-form'));
 assert.equal(w.document.querySelector('[name=password]').value,'');assert.equal(w.localStorage.length,0);
 assert.equal(w.document.querySelector('.workspace'),null);
});
test('dashboard displays supplied real counts and role-filtered links',async()=>{
 const {w}=await app('lab');assert.ok(w.document.querySelector('[data-page=lab]'));
 assert.equal(w.document.querySelector('[data-page=users]'),null);
 assert.equal(w.document.querySelector('[data-page=patients]'),null);
 assert.ok(w.document.querySelector('.stats').textContent.includes('مریضان ثبت‌شده'));
});
test('all twenty templates are selectable and admin selection persists via CSRF',async()=>{
 const {w,api,requests}=await app();await api.navigate('templates');
 assert.equal(w.document.querySelectorAll('.template-card').length,20);
 w.document.querySelector('[data-action=template-select][data-id="20"]').click();
 for(let i=0;i<4;i++)await settle();
 const request=requests.find(r=>r.url==='/api/hospital'&&r.options.method==='PUT');
 assert.ok(request);assert.equal(JSON.parse(request.options.body).template_id,20);
 assert.equal(request.options.headers['X-CSRF-Token'],'test-csrf');
});
test('patient names and user input are escaped rather than interpreted as HTML',async()=>{
 const {w,api}=await app();await api.navigate('patients');api.S.patients[0]={...person,first_name:'<img src=x onerror=alert(1)>'};
 // Render via the same preview renderer and inspect the resulting DOM.
 const rx={id:1,patient:api.S.patients[0],doctor:'<script>bad()</script>',created:1,status:'draft',complaint:'<svg onload=alert(1)>',diagnosis:'test',notes:'',items:[]};
 const node=w.document.createElement('div');node.innerHTML=api.printSheet(rx,1);
 assert.equal(node.querySelector('img'),null);assert.equal(node.querySelector('script'),null);assert.equal(node.querySelector('svg'),null);
 assert.ok(node.textContent.includes('<img src=x'));
});
test('new prescription has no forced drug, dose, serum or injection',async()=>{
 const {w,api}=await app('doctor');await api.rxModal(1);
 assert.equal(w.document.querySelectorAll('.rx-item').length,0);
 assert.deepEqual(JSON.parse(JSON.stringify(api.readRx().items)),[]);
 w.document.querySelector('[data-action=rx-add]').click();await settle();
 assert.equal(w.document.querySelector('[name=dose]').value,'');
 assert.equal(w.document.querySelector('[name=form]').value,'');
});
test('all print layouts preserve clinical data and draft watermark',async()=>{
 const {api}=await app('doctor');
 const rx={id:5,patient:person,doctor:'داکتر آزمایشی',created:1,status:'draft',complaint:'TEST COMPLAINT',diagnosis:'TEST DIAGNOSIS',notes:'TEST NOTES',items:[{name:'TEST MEDICINE',form:'TEST FORM',dose:'MANUAL DOSE',frequency:'MANUAL FREQUENCY',duration:'MANUAL DURATION',quantity:1,instructions:'MANUAL INSTRUCTIONS'}]};
 for(let id=1;id<=20;id++){
  const content=api.printSheet(rx,id);
  for(const value of ['TEST MEDICINE','MANUAL DOSE','TEST COMPLAINT','TEST NOTES','ASH-0000001','پیش‌نویس'])assert.ok(content.includes(value));
 }
});
test('confirmed print uses archived hospital information, not current settings',async()=>{
 const {api}=await app('doctor');const rx={id:1,patient:person,hospital:{...fixtures.hospital,name:'ARCHIVED HOSPITAL'},doctor:'test',created:1,status:'confirmed',complaint:'test',diagnosis:'test',notes:'',items:[]};
 const content=api.printSheet(rx,1);assert.ok(content.includes('ARCHIVED HOSPITAL'));assert.ok(!content.includes('شفاخانهٔ آزمایشی'));
});
test('logout clears visible patient data and prepared print content',async()=>{
 const {w,api}=await app();await api.navigate('patients');w.document.querySelector('#print-root').textContent='SENSITIVE TEST';
 w.document.querySelector('[data-action=logout]').click();for(let i=0;i<4;i++)await settle();
 assert.ok(w.document.querySelector('#login-form'));assert.equal(w.document.querySelector('#print-root').textContent,'');
 assert.equal(api.S.patients.length,0);assert.equal(api.S.csrf,'');
});
