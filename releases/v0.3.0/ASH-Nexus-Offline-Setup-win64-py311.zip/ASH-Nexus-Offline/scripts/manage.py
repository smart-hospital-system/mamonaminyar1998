"""Local setup/backup/restore CLI. Never pass passwords through command arguments."""
import argparse
import getpass
import os
from pathlib import Path
import sqlite3
from sqlalchemy import inspect, select
from backend.app.backups import SCHEMA_VERSION, restore_to_new, snapshot
from backend.app.database import open_database
from backend.app.models import Base, Setting, User
from backend.app.routers.system import DEFAULT_HOSPITAL
from backend.app.security import hash_password
import json

ROOT = Path(__file__).resolve().parents[1]


def initialize(path, username, name, password, hospital=None, activation=None):
    if len(password) < 12 or len(password) > 200:
        raise ValueError('Use a unique password between 12 and 200 characters.')
    engine, sessions = open_database(path)
    try:
        if inspect(engine).get_table_names():
            raise ValueError('Database already has tables. Setup never overwrites an existing database.')
        Base.metadata.create_all(engine)
        with sessions() as db:
            db.add(User(username=username.strip().lower(), name=name, role='admin', password_hash=hash_password(password)))
            db.add(Setting(key='schema_version', value=SCHEMA_VERSION))
            db.add(Setting(key='hospital', value=json.dumps(hospital or DEFAULT_HOSPITAL, ensure_ascii=False)))
            if activation is not None:
                db.add(Setting(key='activation', value=json.dumps(activation, ensure_ascii=False)))
            db.commit()
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass  # Windows requires NTFS ACLs; see deployment instructions.
    finally:
        engine.dispose()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db', type=Path, default=Path(os.environ.get('ASH_DB_PATH', ROOT / '.data' / 'ash.sqlite3')))
    sub = parser.add_subparsers(dest='command', required=True)
    init = sub.add_parser('init')
    init.add_argument('--username', default='admin')
    init.add_argument('--name', default='مدیر سیستم')
    backup = sub.add_parser('backup')
    backup.add_argument('destination', type=Path)
    restore = sub.add_parser('restore')
    restore.add_argument('source', type=Path)
    restore.add_argument('destination', type=Path, help='NEW path, must not exist')
    migration = sub.add_parser('upgrade-v1', help='Additive upgrade to a NEW database file')
    migration.add_argument('source', type=Path)
    migration.add_argument('destination', type=Path)
    args = parser.parse_args()
    try:
        if args.command == 'init':
            password = getpass.getpass('New administrator password (12+ characters): ')
            if password != getpass.getpass('Repeat password: '):
                raise ValueError('Passwords do not match.')
            initialize(args.db.resolve(), args.username, args.name, password)
            print('Initialized. Start: python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000')
        elif args.command == 'backup':
            if not args.db.is_file():
                raise ValueError('Source database does not exist.')
            args.destination.parent.mkdir(parents=True, exist_ok=True)
            fd = os.open(args.destination, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            os.close(fd)
            engine, _ = open_database(args.db)
            try:
                snapshot(engine, args.destination)
            finally:
                engine.dispose()
            print('Backup created. Contains sensitive records; encrypt before moving.')
        elif args.command == 'upgrade-v1':
            from scripts.upgrade_database import upgrade
            upgrade(args.source, args.destination)
            print('Schema 2 created at NEW path. Original preserved. Stop old server; explicitly select new DB.')
        else:
            restore_to_new(args.source, args.destination)
            print('Restored to NEW path; sessions invalidated. Stop the server, set ASH_DB_PATH, then restart.')
    except (ValueError, OSError, sqlite3.DatabaseError) as error:
        parser.exit(1, f'ERROR: {error}\n')


if __name__ == '__main__':
    main()
